<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clothes Shop</title>
    <link href="https://fonts.googleapis.com/css2?family=Ribeye+Marrow&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="<?php echo e(asset('js/carousel.js')); ?>"></script>
    <script src="https://kit.fontawesome.com/dff7dacd30.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="container">
    <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="main">
            <div class="product1">
                <h2 class="title">Quần Áo Nam</h2>
                <hr class="line"></hr>
                <ul class="product-ul">
                <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="/shopWeb/public/detail/<?php echo e($n->id); ?>">
                        <img class="product-img" width="180" height="200" src="../<?php echo e($n->image); ?>">
                        <p class="product-name"><?php echo e($n->tenSP); ?></p>
                        <p class="product-prize"><?php echo e($n->gia); ?> đ</p>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <span class="btn-xemthem"><a href="#">Xem thêm</a></span>
            </div>
        </div>
        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
   
</body>
</html><?php /**PATH C:\xampp\htdocs\shopWeb\resources\views/collection.blade.php ENDPATH**/ ?>