<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clothes Shop</title>
    <link href="https://fonts.googleapis.com/css2?family=Ribeye+Marrow&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="<?php echo e(asset('js/carousel.js')); ?>"></script>
    <script src="https://kit.fontawesome.com/dff7dacd30.js" crossorigin="anonymous"></script>
    
</head>
<body>
    <div class="container">
        <div class="header">
            <span class="logo"><a href="#"><img src="<?php echo e(asset('img/icon/logo.png')); ?>"></a></span>
            <div class="header-right">
                <p id="contact"><a href="#">Contact: phananhnhat2@gmail.com</a></p>
                <div class="social-network" style="font-size: 18px;">
                    <i class="fab fa-facebook-square fa-lg"></i>
                    <i class="fab fa-twitter-square fa-lg"></i>
                    <i class="fab fa-instagram-square fa-lg"></i>
                </div>
                <div class="search">
                    <form class="search-form" action="" method="">
                        <input type="text" id="search-box" placeholder="Tìm kiếm">
                        <button type="button" id="btn-search">Search</button>
                    </form>
                    <span id="btn-login"><a href="<?php echo e(URL::to('/login')); ?>">Đăng Nhập</a></span>
                    <span id="btn-register"><a href="<?php echo e(URL::to('/login')); ?>">Đăng Ký</a></span>
                </div>
            </div>
        </div>
        <!-- End navbar -->
        <div class="main">
            <div class="menu-slide">
                <div class="menu">
                    <ul class="menu-ul">
                        <?php $__currentLoopData = $danhmuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/shopWeb/public/collection/<?php echo e($dm->id); ?>"><?php echo e($dm->ten); ?></a></li><hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul> 
                </div>
                <div class="carousel">
                 
                    <div class="carousel__track-container">
                        <ul class="carousel__track">
                            <li class="carousel__slide current-slide">
                                <img src="../../public/img/poster/banner_slide.jpg" alt="">
                            </li>
                            <li class="carousel__slide">
                                <img src="../../public/img/poster/banner_slide.jpg" alt="">
                            </li>
                            <li class="carousel__slide">
                                <img src="../../public/img/poster/banner_slide.jpg" alt="">
                            </li>
                        </ul>
                    </div>
                    <div class="carousel__button carousel__button--left">
                        <i class="fas fa-angle-left fa-2x"></i>
                    </div>
                  <div class="carousel__button carousel__button--right">
                        <i class="fas fa-angle-right fa-2x"></i>
                  </div>
                  <div class="carousel__nav">
                    <button class="carousel__indicator current-slide"></button>
                    <button class="carousel__indicator"></button>
                    <button class="carousel__indicator"></button>
                  </div>
                </div>
            </div>
            <!-- End slide -->
            <div class="product1">
                <h2 class="title">Quần Áo Nam</h2>
                <hr class="line"></hr>
                <ul class="product-ul">
                <?php $__currentLoopData = $nam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <li><a href="/shopWeb/public/detail/<?php echo e($n->id); ?>">
                        <img class="product-img" width="180" height="200" src="<?php echo e($n->image); ?>">
                        <p class="product-name"><?php echo e($n->tenSP); ?></p>
                        <p class="product-prize"><?php echo e($n->gia); ?> đ</p>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <span class="btn-xemthem"><a href="/shopWeb/public/collection/<?php echo e($n->idDM); ?>">Xem thêm</a></span>
            </div>
            <div class="product2">
                <h2 class="title">Quần Áo Nữ</h2>
                <hr class="line"></hr>
                <ul class="product-ul">
                <?php $__currentLoopData = $nu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="/shopWeb/public/detail/<?php echo e($g->id); ?>">
                        <img width="180" height="200" src="<?php echo e($g->image); ?>">
                        <p class="product-name"><?php echo e($g->tenSP); ?></p>
                        <p class="product-prize"><?php echo e($g->gia); ?> đ</p>
                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <span class="btn-xemthem"><a href="/shopWeb/public/collection/<?php echo e($g->idDM); ?>">Xem thêm</a></span>
            </div>
        
            <!-- Page 1 -->
            <div class="product2">
                <h2 class="title">Quần Áo Nữ</h2>
                <hr class="line"></hr>
                <ul class="product-ul">
                <?php $__currentLoopData = $nu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><img width="180" height="200" src="<?php echo e($sp->image); ?>">
                        <p class="product-name"><?php echo e($sp->tenSP); ?></p>
                        <p class="product-prize"><?php echo e($sp->gia); ?> đ</p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <span class="btn-xemthem">Xem thêm</span>
            </div>

            <div class="footer">

            </div>
        </div>

    </div>
   
</body>
</html><?php /**PATH C:\xampp\htdocs\shopWeb\resources\views/home.blade.php ENDPATH**/ ?>