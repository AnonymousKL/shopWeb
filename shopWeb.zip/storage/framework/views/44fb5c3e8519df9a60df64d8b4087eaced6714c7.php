<div class="footer">

</div><?php /**PATH C:\xampp\htdocs\shopWeb\resources\views/inc/footer.blade.php ENDPATH**/ ?>