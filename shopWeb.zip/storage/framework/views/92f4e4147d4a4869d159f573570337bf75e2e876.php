

<?php $__env->startSection('content'); ?>
<h2>Add banner/Ads</h2>
    <form action="<?php echo e(URL::to('/product/addimage')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <label for="type">Loại banner:</label>
                <input type="text" class="form-control" placeholder="Enter email" name="type">
            </div>
            <div class="form-group">
                <label for="link">Liên kết:</label>
                <input type="text" class="form-control" placeholder="Enter email" name="link">
            </div>
            <div class="form-group">
                <label for="banner">Banner:</label>
                <input type="file" class="form-control" placeholder="Enter email" name="banner">
            </div>
                <button type="submit" class="btn btn-primary">Upload</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopWeb\resources\views/admin/addimage.blade.php ENDPATH**/ ?>